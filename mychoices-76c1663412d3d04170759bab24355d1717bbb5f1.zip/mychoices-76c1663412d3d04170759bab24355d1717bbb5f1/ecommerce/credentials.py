django_secret_key = "ibn$_f0kduow2f54v$8p0pya0hff$i6-f@t^$f8ds897sj38eh"
email = "q@gmail.com" 
host = "smtp.gmail.com"
host_user = "q@gmail.com"
host_password = "A"
secret_key = 'sk_test_51IMsNuIUjoXbj7koYERtkUURXTASWol0MpRAQF45tJsEvOWd2toWPtYvPRDANBWkjTyQtG3G9ZWHNRYAdcGPkuM700lqlBf5vu'
publishable_key = 'pk_test_51IMsNuIUjoXbj7koDjVZotwuWjrh6PqKV3y2breyaycbGJRJxhWtMOpHHsX1miuRvirLsQ695TmhaFhSg3ImvtQ500eH7rcReS'