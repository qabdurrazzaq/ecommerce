# ecommerce
ecommerce website developed using Python (v-3.8) and Django (v-3.1.5)
